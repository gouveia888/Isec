package pt.isec.amov.AMOV_Dialogs

import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import pt.isec.amov.AMOV_Dialogs.databinding.ActivityMainBinding
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.btnDialogClassic.setOnClickListener { showAlertDialog() }
        binding.btnDateTime.setOnClickListener { pickDateTime() }
        binding.btnFragment.setOnClickListener { showDialog ()  }
        binding.btnDialogActivity.setOnClickListener {
            val intent = Intent(this, DialogActivity::class.java)
            startActivity(intent)
        }
    }

    // Fragment Dialog
    private fun showDialog() {
        val dialogFragment = CustomDialogFragment()
        dialogFragment.show(supportFragmentManager, "My Dialog")
    }

    // Classic Dialog
    private fun showAlertDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Confirmation")
        builder.setMessage("Do you want to proceed with the operation?")
        builder.setIcon(R.drawable.ic_info) // Set your drawable icon here

        // Positive button
        builder.setPositiveButton("Yes") { dialog, _ ->
            // Action on "Yes"
            Toast.makeText(this, "You clicked Yes", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        // Negative button
        builder.setNegativeButton("No") { dialog, _ ->
            // Action on "No"
            Toast.makeText(this, "You clicked No", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        // Neutral button
        builder.setNeutralButton("Cancel") { dialog, _ ->
            // Action on "Cancel"
            Toast.makeText(this, "Operation canceled", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.show()
    }

    // Dialog with Date and Time picker
    private fun pickDateTime() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                TimePickerDialog(
                    this,
                    { _, selectedHour, selectedMinute ->
                        val result = "%02d/%02d/%04d %02d:%02d"
                            .format(selectedDayOfMonth, selectedMonth + 1, selectedYear, selectedHour, selectedMinute)
                        binding.resultTextView.text = result
                    },
                    hour, minute, true
                ).show()
            },
            year, month, day
        ).show()
    }
}

// Define your DialogFragment
class CustomDialogFragment : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("Sample Dialog")
            .setMessage("This dialog is managed as a DialogFragment.")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
    }

    companion object {
        const val TAG = "CustomDialogFragment"
    }
}