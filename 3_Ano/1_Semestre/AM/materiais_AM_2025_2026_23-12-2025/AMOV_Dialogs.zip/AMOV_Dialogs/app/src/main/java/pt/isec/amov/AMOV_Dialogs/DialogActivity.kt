package pt.isec.amov.AMOV_Dialogs

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import pt.isec.amov.AMOV_Dialogs.databinding.ActivityDialogBinding

class DialogActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDialogBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDialogBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // Setup dialog UI, e.g., buttons and text
        binding.closeButton.setOnClickListener {
            finish() // Close the dialog activity
        }
    }
}