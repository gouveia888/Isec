package pt.isec.amov.listview

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class NotaAdapter(private val context: Context, private val notas: List<Nota>) : BaseAdapter() {

    override fun getCount(): Int = notas.size // number of items in the data source
    override fun getItem(position: Int): Nota = notas[position] // get item at position
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.list_item_nota, parent, false)
        val nota = getItem(position)

        val imgIcon = view.findViewById<ImageView>(R.id.imgIcon)
        val tvTitulo = view.findViewById<TextView>(R.id.tvTitulo)
        val tvDataHora = view.findViewById<TextView>(R.id.tvDataHora)

        imgIcon.setImageResource(nota.iconeResId)
        tvTitulo.text = nota.titulo
        tvDataHora.text = nota.dataHora

        return view
    }
}