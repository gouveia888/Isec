package pt.isec.amov.listview

import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.RouteListingPreference
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

import android.widget.SimpleAdapter
import android.widget.SimpleCursorAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.android.volley.toolbox.JsonArrayRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import pt.isec.amov.listview.databinding.ActivityMainBinding
import java.net.URL


class MainActivity : AppCompatActivity() {
    val notas = listOf(
        Nota("To do", "Nov 16, 2023 25:51:33 AM", R.drawable.ic_note),
        Nota("Note to self", "Sep 27, 2024 16:51:33 AM", R.drawable.ic_pencil),
        Nota("Important", "Nov 18, 2024 16:51:33 PM", R.drawable.ic_pencil),
        Nota("Shopping list", "Dec 1, 2024 16:51:33 AM", R.drawable.ic_pencil),
        Nota("Another note", "Nov 15, 2025 17:51:33 PM", R.drawable.ic_note),
        Nota("Just a note", "Jan 13, 2020 12:34:56 AM", R.drawable.ic_note),
        Nota("Random thought", "Nov 24, 2021 13:51:33 PM", R.drawable.ic_pencil),
        Nota("Quick reminder", "Mar 15, 2022 14:51:33 AM", R.drawable.ic_note),
        Nota("To do", "Nov 16, 2023 25:51:33 AM", R.drawable.ic_note),
        Nota("Note to self", "Sep 27, 2024 16:51:33 AM", R.drawable.ic_pencil),
        Nota("Important", "Nov 18, 2024 16:51:33 PM", R.drawable.ic_pencil),
        Nota("Shopping list", "Dec 1, 2024 16:51:33 AM", R.drawable.ic_pencil),
        Nota("Another note", "Nov 15, 2025 17:51:33 PM", R.drawable.ic_note),
        Nota("Meeting notes", "Aug 21, 2014 16:51:33 PM", R.drawable.ic_pencil),
        Nota("Idea", "Feb 14, 2022 16:51:33 AM", R.drawable.ic_pencil)
    )
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)
        setSupportActionBar(binding.toolbar)

        binding.btnArrayAdpt.setOnClickListener() { // a) ArrayAdapter<T>
            binding.headerList.tvHeaderTitle.text="ArrayAdapter from XML"
            // val list = listOf("AMOV", "PWEB", "GPS ") // OU ---
            val list: Array<String> = resources.getStringArray(R.array.unidadesCurriculares)
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
            binding.listViewNotas.adapter = adapter
        }
        binding.btnSimpleAdpt.setOnClickListener() { // b) SimpleAdapter
            binding.headerList.tvHeaderTitle.text="SimpleAdapter"
            val list = ArrayList<Map<String, String>>()
            list.add (mapOf("title" to "To do", "date" to "23/10/2025"))
            list.add (mapOf("title" to "Shopping list", "date" to "11/12/2024"))

            val from = arrayOf("title", "date")
            val to = intArrayOf(R.id.tvTitulo, R.id.tvDataHora)

            val adapter = SimpleAdapter(this, list, R.layout.list_item_nota, from, to)
            binding.listViewNotas.adapter = adapter
        }
        binding.btnCustomAdpt.setOnClickListener() { // c) Custom Adapter (BaseAdapter)
                    binding.headerList.tvHeaderTitle.text="Custom Adapter"

                    val adapter = NotaAdapter(this, notas)
                    Toast.makeText(this,adapter.count.toString() + " items",Toast.LENGTH_LONG).show()
                    // Toast.makeText(this,adapter.getItem(1).titulo.toString(),Toast.LENGTH_LONG).show()
                    binding.listViewNotas.adapter = adapter
        }
        binding.btnCursorAdpt.setOnClickListener() { // d) Cursor Adapter
            binding.headerList.tvHeaderTitle.text="Cursor Adapter"
            lifecycleScope.launch {
                // Parse JSON to create a cursor
                val jsonString =
                    fetchUrl("https://www.joaoafonso.pt/amov") // function to download the JSON string
                val jsonArray = JSONArray(jsonString)
                val columns = arrayOf("_id", "titulo", "dataHora")
                val cursor = MatrixCursor(columns)

                // Populate MatrixCursor with JSON data
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    cursor.addRow(
                        arrayOf(obj.getInt("_id"),obj.getString("titulo"), obj.getString("dataHora")   )) }

                // Now create SimpleCursorAdapter
                val from = arrayOf("titulo", "dataHora")
                val to = intArrayOf(R.id.tvTitulo, R.id.tvDataHora)

                val adapter = SimpleCursorAdapter(
                    this@MainActivity,    // Context
                    R.layout.list_item_nota,     // Layout with TextViews (tvTitulo, tvdataHora)
                    cursor,                      // Cursor from MatrixCursor created above
                    from,                        // Columns to fetch from cursor
                    to,                          // Views to bind data to
                    0                       // Flags
                )
                binding.listViewNotas.adapter = adapter
            }
        }
        binding.btnRecycler.setOnClickListener() { // RecyclerView
            binding.headerListRecycler.tvHeaderTitle.text="RecyclerView"

            //binding.recyclerViewNotas.layoutManager = LinearLayoutManager(this) // To display using LinearLayout
            //binding.recyclerViewNotas.layoutManager = StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL) // using Grid
            binding.recyclerViewNotas.layoutManager = GridLayoutManager(this, 3) // using columns

            // [optional] to add Item decoration
            binding.recyclerViewNotas.addItemDecoration(DividerItemDecoration(
                binding.recyclerViewNotas.context,
                DividerItemDecoration.VERTICAL))

            binding.recyclerViewNotas.adapter = NotaAdapterRecycler(notas) {
                nota ->
                Toast.makeText(this, "Selected: $nota", Toast.LENGTH_SHORT).show()}
        }

        binding.listViewNotas.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position).toString()
            AlertDialog.Builder(this)
                .setTitle("Item Selected")
                .setMessage("You selected: $selectedItem")
                .setPositiveButton("OK", null)
                .show()
        }
    }
}

// Function to fetch JSON string from URL
suspend fun fetchUrl(urlString: String): String {
    return withContext(Dispatchers.IO) {
        URL(urlString).readText()
    }
}