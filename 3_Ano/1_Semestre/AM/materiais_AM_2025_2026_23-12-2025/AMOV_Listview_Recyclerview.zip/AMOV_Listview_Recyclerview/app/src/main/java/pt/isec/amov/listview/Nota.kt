package pt.isec.amov.listview

data class Nota(
    val titulo: String,
    val dataHora: String,
    val iconeResId: Int
)
