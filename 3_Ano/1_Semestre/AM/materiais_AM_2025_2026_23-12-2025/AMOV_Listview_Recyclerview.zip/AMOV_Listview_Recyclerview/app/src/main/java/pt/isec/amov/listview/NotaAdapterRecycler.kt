package pt.isec.amov.listview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NotaAdapterRecycler (private val notas: List<Nota>,private val onItemClick: (String) -> Unit) :
    RecyclerView.Adapter<NotaAdapterRecycler.NotaViewHolder>() {

    class NotaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val Titulo: TextView = itemView.findViewById(R.id.tvTitulo)
        val DataHora: TextView = itemView.findViewById(R.id.tvDataHora)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_nota, parent, false)
        return NotaViewHolder(view)
    }

    override fun onBindViewHolder(holder: NotaViewHolder, position: Int) {
        holder.Titulo.text = notas[position].titulo
        holder.DataHora.text = notas[position].dataHora
        holder.itemView.setOnClickListener {
            onItemClick(notas[position].titulo)
        }
    }

    override fun getItemCount() = notas.size
}