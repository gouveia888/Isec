package pt.isec.amov.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.Text
import androidx.glance.text.FontWeight
import androidx.glance.text.TextStyle

class WeatherGlanceWidget : GlanceAppWidget() {
    val semiTransparentBlue = Color(0x3300BCD4) // 33 alpha in hex (20% opacity)
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val weatherData = fetchWeatherFromIPMA()

        provideContent {
            Column(modifier = GlanceModifier
                .background(semiTransparentBlue)
                .padding(12.dp)
                .clickable(
                    onClick = actionStartActivity<MainActivity>()
                )
            ) {
                Text(
                    text = "Previsão do Tempo",
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        provider = ImageProvider(weatherData.iconId),
                        contentDescription = "Ícone do tempo",
                        modifier = GlanceModifier.size(24.dp)
                    )
                    Spacer(modifier = GlanceModifier.width(8.dp))
                    Text(text = weatherData.summary, style = TextStyle(fontSize = 14.sp))
                }
            }
        }
    }
}

fun getWeatherIconResource(idWeatherType: Int): Int {
    return when (idWeatherType) {
        1 -> R.drawable.sunny
        2 -> R.drawable.cloudy
        3 -> R.drawable.rain
        else -> R.drawable.sunny
    }
}
