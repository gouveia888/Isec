package pt.isec.amov.widget

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherData(val summary: String, val iconId: Int)

suspend fun fetchWeatherFromIPMA(): WeatherData = withContext(Dispatchers.IO) {
    try { // Coimbra 1060300
        val apiUrl = "https://api.ipma.pt/open-data/forecast/meteorology/cities/daily/1060300.json"
        val url = URL(apiUrl)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000

        val responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_OK) {
            val stream = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(stream)
            val dataArray = json.getJSONArray("data")
            if (dataArray.length() > 0) {
                val todayForecast = dataArray.getJSONObject(0)
                val tMin = todayForecast.getString("tMin")
                val tMax = todayForecast.getString("tMax")
                val idWeatherType = todayForecast.getInt("idWeatherType")
                val iconRes = getWeatherIconResource(idWeatherType)
                WeatherData("Hoje: $tMin°C - $tMax°C", iconRes)
            } else {
                WeatherData("Sem dados", R.drawable.sunny)
            }
        } else {
            WeatherData("Erro na API", R.drawable.sunny)
        }
    } catch (e: Exception) {
        WeatherData("Falha na rede", R.drawable.sunny)
    }
}
