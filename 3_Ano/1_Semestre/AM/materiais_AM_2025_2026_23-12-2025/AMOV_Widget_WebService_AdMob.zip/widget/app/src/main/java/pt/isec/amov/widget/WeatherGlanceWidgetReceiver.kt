package pt.isec.amov.widget

import androidx.glance.appwidget.GlanceAppWidgetReceiver

class WeatherGlanceWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget = WeatherGlanceWidget()
}
