package pt.isec.amov.AMOV_Fragments

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import pt.isec.amov.AMOV_Fragments.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnA.setOnClickListener()
        {
            val intent = Intent(this, ActivityA::class.java)
            startActivity(intent)
        }
        binding.btnB.setOnClickListener()
        {
            val intent = Intent(this, ActivityB::class.java)
            startActivity(intent)
        }
    }
}