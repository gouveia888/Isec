package pt.isec.amov.AMOV_Fragments
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import pt.isec.amov.AMOV_Fragments.databinding.ActivityABinding

class ActivityA : AppCompatActivity() {
    private lateinit var binding: ActivityABinding
    private val viewModel: CounterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityABinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Button imported using XML
        binding.includeButtons.btnShared.setOnClickListener()
        {
            Toast.makeText(this, "Button pressed in Activity A", Toast.LENGTH_SHORT).show()
            finish ()
        }
        // Button using Fragment
        supportFragmentManager.beginTransaction()
                .replace(binding.fragmentContainer.id, SharedButtonFragment())
                .commit()

        viewModel.count.observe(this, Observer { count ->
            binding.counterA.text = count.toString()
        })
    }

}