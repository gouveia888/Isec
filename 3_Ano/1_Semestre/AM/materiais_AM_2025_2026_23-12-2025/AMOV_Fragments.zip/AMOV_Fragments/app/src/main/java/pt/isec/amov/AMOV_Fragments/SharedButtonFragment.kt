package pt.isec.amov.AMOV_Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import pt.isec.amov.AMOV_Fragments.databinding.FragmentSharedButtonBinding


class SharedButtonFragment : Fragment() {
    private val viewModel: CounterViewModel by activityViewModels()
    //private val viewModel: CounterViewModel by viewModels()
    private var _binding: FragmentSharedButtonBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSharedButtonBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnShared.setOnClickListener {
            viewModel.increment()
            Toast.makeText(requireContext(), "´Shared button clicked!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
