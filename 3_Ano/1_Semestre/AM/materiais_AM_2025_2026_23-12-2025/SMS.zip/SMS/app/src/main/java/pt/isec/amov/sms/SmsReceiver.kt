package pt.isec.amov.sms

import android.Manifest.permission_group.SMS
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.util.Log

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.i("AMOV",intent?.action.toString())
        if (intent?.action == "android.provider.Telephony.SMS_RECEIVED") {
            val bundle = intent.extras
            if (bundle != null) {
                val pdus = bundle.get("pdus") as Array<*>
                pdus.forEach { pdu ->
                    val sms = SmsMessage.createFromPdu(pdu as ByteArray)
                    val message = sms.messageBody
                    val sender = sms.originatingAddress
                    Log.d("SmsReceiver", "SMS from $sender: $message")

                    SmsMessageHolder.latestMessage = "From $sender: $message"

                    // Reply to SMS
                    val answer = "Received: $message"
                    if (sender != null) {
                        val smsManager = SmsManager.getDefault()
                        smsManager.sendTextMessage(sender, null, answer, null, null)
                        Log.i("SmsReceiver", "Answer sent to $sender")
                    }
                }
            }
        }
    }
}

object SmsMessageHolder {
    var latestMessage: String = "Waiting for SMS..."
}
