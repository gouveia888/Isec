package pt.isec.amov.sms

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Network
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.livedata.observeAsState
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    // Manifest-Declared receiver
    // - SMS
    // Context-registered receivers
    // 1 - Derived Class - Example with battery change
    // 2 - Anonymous class - Example with plugged in

    var BR_Bat : Battery? = null
    var BR_Plug : BroadcastReceiver? = null

    fun registerBR_Bat() {
        BR_Bat = Battery()
        registerReceiver(BR_Bat, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }
    fun registerBR_Plug() {
        BR_Plug= object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                Log.i("AMOV", "BR: Plugged - onReceive: ")
            }
        }
        registerReceiver(BR_Plug, IntentFilter(Intent.ACTION_POWER_CONNECTED))
    }

    private val viewModel by viewModels<SmsViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerBR_Bat()
        registerBR_Plug()
        var hasSmsPermission by mutableStateOf(false)

        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            hasSmsPermission = isGranted
        }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (hasSmsPermission) {
                        SmsView(viewModel)
                    } else {
                        SmsPermissionScreen(onRequestPermission = {
                            requestPermissionLauncher.launch(Manifest.permission.RECEIVE_SMS)
                            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                        })
                    }
                }
            }
        }

    }

    @Composable
    fun SmsPermissionScreen(onRequestPermission: () -> Unit) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Permission to receive SMS messages is required.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = onRequestPermission) {
                Text("Get permission")
            }
        }
    }

    @Composable
    fun SmsView(viewModel: SmsViewModel) {
        val smsText by viewModel.smsMessage.observeAsState("Waiting for SMS...")

        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = smsText, style = MaterialTheme.typography.headlineMedium)
        }
    }
    override fun onPause() {
        super.onPause()
        if (BR_Bat != null) unregisterReceiver(BR_Bat)
        if (BR_Plug != null) unregisterReceiver(BR_Plug)

    }
}

class Battery : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.i("AMOV","BR: Battery - onReceive: ")
    }
}
