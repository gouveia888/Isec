package pt.isec.amov.sms

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SmsViewModel : ViewModel() {

    private val _smsMessage = MutableLiveData("Waiting SMS...")
    val smsMessage: LiveData<String> = _smsMessage

    init {
        viewModelScope.launch {
            while (true) {
                _smsMessage.postValue(SmsMessageHolder.latestMessage)
                delay(1000)
            }
        }
    }
}
