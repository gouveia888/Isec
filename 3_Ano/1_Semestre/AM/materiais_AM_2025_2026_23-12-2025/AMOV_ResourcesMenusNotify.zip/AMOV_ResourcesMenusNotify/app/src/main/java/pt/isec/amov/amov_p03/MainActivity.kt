package pt.isec.amov.amov_p03

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {
    // Context Menu #1 - Create var
    private lateinit var myTextView: TextView
    // Notification Bar - ChannelId and notificationId
    private val channelId = "amov_channel"
    private val notificationId = 123

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Connects this activity with the UI layout (activity_main.xml)
        setContentView(R.layout.activity_main)

        // Context Menu #2 - Find ad Register the TextView
        myTextView = findViewById(R.id.welcomeText)
        registerForContextMenu(myTextView)

        val btnToast = findViewById<Button>(R.id.btnToast)
        val btnCustomToast = findViewById<Button>(R.id.btnCustomToast)
        val btnSnackbar = findViewById<Button>(R.id.btnSnackbar)
        val btnSnackbarAction = findViewById<Button>(R.id.btnSnackbarAction)
        val btnnotify: Button = findViewById(R.id.notifyButton)

        // Toast - Standard and Custom
        btnToast.setOnClickListener { showSimpleToast() }
        btnCustomToast.setOnClickListener { showCustomToast() }

        // SnackBar - Simple and with Action
        btnSnackbar.setOnClickListener { showSnackbar() }
        btnSnackbarAction.setOnClickListener {
            showSnackbarAction(it)  // 'it' is the clicked button, used as view anchor
        }

        // Notify
        createNotificationChannel()
        btnnotify.setOnClickListener { showNotification() }
    }

    // MENU --- START ---
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.my_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> {
                // Handle search action
                true
            }
            R.id.action_open_settings -> {
                // Handle settings
                true
            }
            R.id.action_open_web -> {
                // Handle settings
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    // MENU --- END  ---

    // CONTEXT MENU --- START ---
    // Also ...  "Context Menu #1" and "Context Menu #2"
    // Create the context menu when user long-presses on view
    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    // Handle context menu item clicks
    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_set_app_name -> {
                myTextView.text=getString(R.string.app_name)
                Toast.makeText(this, R.string.context_set_app_name, Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_reset -> {
                myTextView.text=getString(R.string.welcome_message)
                Toast.makeText(this, R.string.context_reset, Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
    // CONTEXT MENU --- END ---

    // ANIMATION --- START ---
    override fun onResume() {
        super.onResume()
        val myView: View = findViewById(R.id.isecLogo)
        val animation = AnimationUtils.loadAnimation(this, R.anim.zoom)
        myView.startAnimation(animation)
    }
    // ANIMATION --- END  ---

    // TOAST --- START ---
    private fun showSimpleToast() {
        Toast.makeText(this, "AMOV - Simple Toast", Toast.LENGTH_SHORT).show()
    }

    private fun showCustomToast() {
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.custom_toast_layout, null)

        val textView = layout.findViewById<TextView>(R.id.custom_toast_text)
        textView.text = "AMOV - Custom Toast"

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, 100)
        toast.show()
    }
    // TOAST --- END ---

    // SNACKBAR --- START ---
    // SnackBar Duration: Snackbar.LENGTH_SHORT/LENGTH_LONG/LENGTH_INDEFINITE or custom in ms (ex. 5000)
    private fun showSnackbar() {
        Snackbar.make(findViewById(android.R.id.content), "AMOV - Snackbar Message Example", Snackbar.LENGTH_SHORT).show()
    }

    private fun showSnackbarAction(view: android.view.View) {
        Snackbar.make(view, "AMOV - Snackbar with Action", Snackbar.LENGTH_LONG)
            .setAction("Undo") {
                Toast.makeText(this, "Undo clicked", Toast.LENGTH_SHORT).show()
            }
            .setActionTextColor(Color.YELLOW)
            .show()
    }
    // SNACKBAR --- END ---

    // NOTIFICATION BAR --- START ---
    private fun createNotificationChannel() {
        // Run only on Android 8.0 or upper
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "AMOV Channel"
            val descriptionText = "Channel for AMOV  notifications"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    private fun showNotification() {
        // Request notification permission to post for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                return
            }
        }

        // Intent to open MainActivity when notification is tapped
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AMOV - Demo Notification")
            .setContentText("This is a status bar notification example.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent) // Set the pending intent here
            .setAutoCancel(true) // When touched, notification will be removed

        with(NotificationManagerCompat.from(this)) {
            notify(notificationId, builder.build())
        }
    }
    // NOTIFICATION BAR --- END ---
}