import android.content.Context
import android.util.Pair

import android.content.Context
import android.content.SharedPreferences

class PreferencesHelper(context: Context) {

    private val PREFS_NAME = "meu_prefs"
    private val KEY_NOME = "key_nome"
    private val KEY_IDADE = "key_idade"

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Salvar dados (INSERT/UPDATE)
    fun salvarDados(nome: String, idade: Int) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_NOME, nome)
        editor.putInt(KEY_IDADE, idade)
        editor.apply() // de forma assíncrona
    }

    // Ler dados
    fun lerDados(): Pair<String?, Int> {
        val nome = sharedPreferences.getString(KEY_NOME, null)
        val idade = sharedPreferences.getInt(KEY_IDADE, -1)
        return Pair(nome, idade)
    }

    // Deletar dados específicos
    fun deletarNome() {
        val editor = sharedPreferences.edit()
        editor.remove(KEY_NOME)
        editor.apply()
    }

    // Limpar todas as preferências
    fun limparTudo() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }
}