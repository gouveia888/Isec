package pt.isec.amov.storage

import android.content.Context
import android.content.SharedPreferences

class PreferencesHelper(context: Context) {

    private val PREFS_NAME = "my_prefs"
    private val KEY_NAME   = "key_name"
    private val KEY_PHONE  = "key_phone"

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // INSERT/UPDATE
    fun storeData(name: String, phone: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_NAME, name)
        editor.putString(KEY_PHONE, phone)
        editor.apply() // assíncrona
    }

    // READ DATA
    fun readData(): Pair<String?, String?> {
        val name = sharedPreferences.getString(KEY_NAME, null)
        val phone = sharedPreferences.getString(KEY_PHONE, null)
        return Pair(name, phone)
    }

    // DELETE SPECIFIC DATA
    fun deleteName() {
        val editor = sharedPreferences.edit()
        editor.remove(KEY_NAME)
        editor.apply()
    }

    // DELETE ALL PREFERENCES
    fun deleteAll() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }
}
