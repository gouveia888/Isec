package pt.isec.amov.storage

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import pt.isec.amov.storage.databinding.ActivityMainBinding
import java.io.File
import androidx.core.content.edit
import androidx.core.net.toUri

class MainActivity : AppCompatActivity() {
    var readContents: String = ""
    var selectedItem: Int = -1

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        val internalFilename = File(filesDir, "amov.txt") // Int
        val externalFilename = File(getExternalFilesDir(null), "amov.txt") // Ext
        val dbHelper = MyDatabaseHelper(this) // SQLite
        val prefs = getSharedPreferences("my_prefs", MODE_PRIVATE) // Shared Pref

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listView: ListView = findViewById(R.id.listStorage)
        val items = resources.getStringArray(R.array.StorageList)
        val adapter = MyAdapter(this, items)
        listView.adapter = adapter

        // Read
        binding.btRead.setOnClickListener() {
            readContents = ""
            when (selectedItem) {
                0 -> { // Internal Storage
                    if (internalFilename.exists()) {
                        readContents = internalFilename.readText()
                    } else {
                        readContents = "[ERROR] File not found"
                    }
                    Log.i("AMOV", "Internal Storage : $readContents")
                    binding.tvRead.text = readContents
                }

                1 -> { // External Storage
                    if (externalFilename.exists()) {
                        readContents = externalFilename.readText()
                    } else {
                        readContents = "[ERROR] File not found"
                    }
                    Log.i("AMOV", "External Storage : $readContents")
                    binding.tvRead.text = readContents
                }

                2 -> { // SQLite
                    val itens = dbHelper.readContacts()
                    itens.forEach {
                        readContents += "${it.first} ${it.second} ${it.third}\n"
                    }
                    Log.i("AMOV", readContents)
                    binding.tvRead.text = readContents
                }

                3 -> { // Shared Preferences
                    binding.tvRead.text = (prefs.getString("name", "[not available]")) + " " +
                            (prefs.getString("phone", "[not available]"))
                }

                4 -> { // Content Providers
                    // Consultar contatos
                    val cursor = contentResolver.query(
                        Uri.parse("content://pt.isec.amov.contactsprovider/contacts"),
                        arrayOf("name", "phone"),
                        null, null, null
                    )
                    cursor?.use {
                        readContents = ""
                        while (it.moveToNext()) {
                            val name = it.getString(it.getColumnIndexOrThrow("name"))
                            val phone = it.getString(it.getColumnIndexOrThrow("phone"))
                            readContents += "$name - $phone\n"
                        }
                    }
                    Log.i("AMOV", readContents)
                    binding.tvRead.text = readContents
                }

                else -> {
                    binding.tvRead.text = "[ERROR] No storage option selected"
                }
            }
        }

        // Write
        binding.btWrite.setOnClickListener() {
            when (selectedItem) {
                0 -> { // Internal Storage
                    internalFilename.appendText(binding.etName.text.toString() + "," + binding.etPhone.text.toString() + "\n")
                }

                1 -> { // External Storage
                    externalFilename.appendText(binding.etName.text.toString() + "," + binding.etPhone.text.toString() + "\n")
                }

                2 -> { // SQLite
                    // CREATE
                    val newId = dbHelper.addContact(
                        binding.etName.text.toString(),
                        binding.etPhone.text.toString()
                    )
                }

                3 -> { // Shared Preferences
                    prefs.edit { putString("name", binding.etName.text.toString()) }
                    prefs.edit { putString("phone", binding.etPhone.text.toString()) }
                }

                4 -> { // Content Providers
                    // Add contact
                    val values = ContentValues().apply {
                        put("name", binding.etName.text.toString())
                        put("phone", binding.etPhone.text.toString())
                    }
                    contentResolver.insert(
                        "content://pt.isec.amov.contactsprovider/contacts".toUri(),
                        values
                    )
                }

                else -> {
                    binding.tvRead.text = "[ERROR] No storage option selected"
                }
            }
        }

        listView.setOnItemClickListener { parent, view, position, id ->
            adapter.selectedPosition = position
            adapter.notifyDataSetChanged()
            selectedItem = position
        }
    }
}

class MyAdapter(context: Context, val items: Array<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, items) {

    var selectedPosition = -1

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        val textView = view.findViewById<TextView>(android.R.id.text1)

        if (position == selectedPosition) {
            textView.setBackgroundColor(Color.LTGRAY)
        } else {
            textView.setBackgroundColor(Color.TRANSPARENT)
        }
        return view
    }
}