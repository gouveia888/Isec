//
// Created by Henrique Marques on 10/10/2024.
//

#ifndef COFRE_H
#define COFRE_H

#include <string>

using namespace std;

class Cofre {
private:
    int codigo;
    bool aberto;
    const int codigoDesbloqueio;
    int numeroTentativas;
    bool alterandoCodigo;
    int novoCodigo; // Apenas usado enquando se esta a alterar o codigo
    static const int NUM_OBJECTOS = 5;
    static const int NUM_MAX_TENTATIVAS = 3;
    string objectos[NUM_OBJECTOS];

public:
    Cofre(int codigo, int codigoDesbloqueio, bool aberto):
    codigo(codigo), codigoDesbloqueio(codigoDesbloqueio), aberto(aberto),
    numeroTentativas(0), alterandoCodigo(false), objectos{} {}
    Cofre(int codigoDesbloqueio):
    codigoDesbloqueio(codigoDesbloqueio), aberto(true), codigo(0),
    numeroTentativas(0), alterandoCodigo(false), objectos{} {}

    bool estaAberto() const;
    bool estaBloqueado() const;
    int numeroTentativasRestantes() const;
    string obtemObjectos() const;
    bool contemObjecto(const string& objecto) const;

    bool fechar();
    bool abrir(int codigo);
    bool desbloqueia(int codigoDesbloqueio);
    bool alteraCodigo(int codigoAtual, int novoCodigo);
    bool adicionaObjecto(string obj);
    bool removeObjecto(string obj);

};



#endif //COFRE_H
