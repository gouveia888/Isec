//
// Created by Henrique Marques on 10/10/2024.
//

#include "Cofre.h"
#include <sstream>

bool Cofre::estaAberto() const
{
    return aberto;
}

bool Cofre::estaBloqueado() const
{
    return numeroTentativas == NUM_MAX_TENTATIVAS;
}

int Cofre::numeroTentativasRestantes() const
{
    return NUM_MAX_TENTATIVAS - numeroTentativas;
}

string Cofre::obtemObjectos() const
{
    if (!this->estaAberto())
    {
        return "Cofre fechado";
    }
    ostringstream oss;
    for (int i = 0; i < NUM_OBJECTOS; i++)
    {
        // [1]: Relogio
        // [2]: Carteira
        oss << "[" << i+1 << "]: " << objectos[i] << endl;
    }
    return oss.str();
}

bool Cofre::contemObjecto(const string& objecto) const
{
    for (string obj : objectos)
    {
        if (obj == objecto)
            return true;
    }
    return false;
}

bool Cofre::fechar()
{
    this->alterandoCodigo = false;
    if (estaBloqueado())
        return false;
    aberto = false;
    return true;
}

bool Cofre::abrir(int codigo)
{
    this->alterandoCodigo = false;
    if (this->estaBloqueado())
        return false;
    if (this->estaAberto())
        return false;
    if (codigo == this->codigo)
    {
        aberto = true;
        numeroTentativas = 0;
        return true;
    }
    ++numeroTentativas;
    return false;
}

bool Cofre::desbloqueia(int codigoDesbloqueio)
{
    this->alterandoCodigo = false;
    if (this->estaBloqueado() && codigoDesbloqueio == this->codigoDesbloqueio)
    {
        numeroTentativas = 0;
        aberto = true;
        return true;
    }
    return false;
}

bool Cofre::alteraCodigo(int codigoAtual, int novoCodigo)
{
    if (!this->estaAberto())
    {
        return false;
    }
    if (codigoAtual == this->codigo)
    {
        if (this->alterandoCodigo)
        {
            if (this->novoCodigo == novoCodigo)
            {
                this->codigo = novoCodigo;
                this->numeroTentativas = 0;
                this->alterandoCodigo = false;
                return true;
            } else
            {
                this->alterandoCodigo = false;
                this->novoCodigo = 0; // Podiamos fazer isto mas era indiferente
                return false;
            }
        }
        this->alterandoCodigo = true;
        this->novoCodigo = novoCodigo;
        return false; // Ainda nao alterou o codigo, sera na invocacao seguinte
    }
    this->alterandoCodigo = false;
    return false;
}

bool Cofre::adicionaObjecto(string obj)
{
    this->alterandoCodigo = false;
    if (obj.empty())
    {
        return false;
    }
    if (!this->estaAberto())
        return false;
    for (int i = 0; i < NUM_OBJECTOS; i++)
    {
        if (this->objectos[i].empty()) // Espaco vazio e representado por string vazia
        {
            this->objectos[i] = obj;
            return true;
        }
    }
    return false;
}

bool Cofre::removeObjecto(string obj)
{
    this->alterandoCodigo = false; // Cancelar o processo de alteracao de codigo
    if (obj.empty())
    {
        return false;
    }
    if (!this->estaAberto())
        return false;
    for (int i = 0; i < NUM_OBJECTOS; i++)
    {
        if (this->objectos[i] == obj)
        {
            this->objectos[i].clear();
            return true;
        }
    }
    return false;
}
