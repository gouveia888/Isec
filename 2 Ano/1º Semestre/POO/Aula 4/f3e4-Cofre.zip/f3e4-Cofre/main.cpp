#include <iostream>
#include "Tabela.h"
#include "Cofre.h"

using namespace std;

void recebe(Tabela t) {
}

Tabela devolve() {
    Tabela t;
    return t;
}

Tabela inicializa() {
    cout << "inicializa" << endl;
    Tabela t1(1);
    Tabela t2 = t1;
    return t2;
}

int main() {
    Cofre c(12345678); // Esta aberto, codigo inicial 0
    Cofre a(9999, 87654321, false); //Esta fechado
    // testar aberto
    cout << "Cofre c esta aberto? " << c.estaAberto() << endl;
    cout << "Cofre a esta aberto? " << a.estaAberto() << endl;

    // testar bloqueado
    cout << "Cofre c esta bloqueado? " << c.estaBloqueado() << endl;
    cout << "Cofre a esta bloqueado? " << a.estaBloqueado() << endl;

    cout << "Numero tentativas: " << "c: " << c.numeroTentativasRestantes()
    << " a: " << a.numeroTentativasRestantes() << endl;

    cout << "Items Cofre c: " << endl << c.obtemObjectos() << endl;
    cout << "Items Cofre a: " << endl << a.obtemObjectos() << endl;

    c.alteraCodigo(0, 1234); // Iniciar alteracao de codigo
    c.alteraCodigo(0, 1234); // Finalizar alteracao de codigo

    c.fechar();
    cout << "Cofre c esta aberto? " << c.estaAberto() << endl;

    int codigo = 0;
    cout << "Introduza o codigo para abrir o cofre c: ";
    cin >> codigo;
    c.abrir(codigo);
    cout << "Cofre c esta aberto? " << c.estaAberto() << endl;

    c.adicionaObjecto("Relogio");
    c.adicionaObjecto("Carteira");
    c.adicionaObjecto("Telemovel");
    cout << "Items Cofre c: " << endl << c.obtemObjectos() << endl;

    c.removeObjecto("Relogio");
    cout << "Items Cofre c: " << endl << c.obtemObjectos() << endl;

    c.fechar();
    c.abrir(0);
    c.abrir(0);
    c.abrir(0); // errar o codigo 3 vezes, vai bloquear
    cout << "Cofre c esta bloqueado? " << c.estaBloqueado() << endl;

    c.desbloqueia(12345678);
    cout << "Cofre c esta bloqueado? " << c.estaBloqueado() << endl;
}

